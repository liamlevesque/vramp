define([
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/ready",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    'dojo/query',
    "dojo/dom-style",
    "dojo/_base/array",
    "dojo/_base/fx",
	"dojo/fx"
], function(connect, declare, ready, widgetBase, templatedMixin, query, domStyle, array, fx, coreFx) {
	
	return declare("amd/display/LanguageLabel", [widgetBase, templatedMixin], {
		
		templateString:  "<${rootElement} data-dojo-attach-point='apLabel'></${rootElement}>"
			
		, laneID : ''
			
	    , fieldid : ''
	    	
	    , mytype : ''
	        	  
	    , isBlinkable : false
	          	  
	    , blinkNum : 10
	            
	    , blinkAnimation : null
	    
	    , rootElement : 'span'
	    	   	
		, mySubscriptions : []
	
		, postMixInProperties: function() {
			
			this.inherited(arguments);
			
			var aSub = null;
			this.mySubscriptions = [];
			aSub = connect.subscribe("AttendManager/LanguageLabel/SetValue/" + this.laneID, this, this.gotValue);
			this.mySubscriptions.push(aSub);
			aSub = connect.subscribe("Anyone/LanguageLabel/Blink/" + this.laneID, this, this.blink);
			this.mySubscriptions.push(aSub);
		}
	
		, postCreate : function() {
			
			
			
			this.inherited(arguments);

		}

		, destroy : function() {
			
			 for(aSub in this.mySubscriptions) {
				 
		  		  connect.unsubscribe(this.mySubscriptions[aSub]);
		  	  }
		}
	
		, gotValue : function(langPack, language) {
            if(language === 'ja_jp'){
                dojo.query(".js--vramp-bidding").addClass("lang--jpy");
            		//domStyle.set(query(".font--300")[0], 'fontSize', '1.5rem');
            }else if(language === 'zh_cn'){
            		dojo.query(".js--vramp-bidding").addClass("lang--cn");
            		//domStyle.set(query(".font--300")[0], 'fontSize', '1.2rem');
            }
			this.apLabel.innerHTML = langPack[this.mytype];
        }

		, blink : function(mytype) {
			
			/*if (this.isBlinkable && this.mytype == mytype) {
				
				var effects = [];
				var hide = fx.fadeOut({node: this.domNode, duration: 100});
				var show = fx.fadeIn({node: this.domNode, duration: 100});
			
				for(var i = 0; i < 10; i++) {
					
					effects.push(hide);
					effects.push(show);
				}
			
				if (this.blinkAnimation) {
					
					this.blinkAnimation.stop();
				}
				this.blinkAnimation = coreFx.chain(effects).play();
				
			}*/
		}
		
		
	});
});
