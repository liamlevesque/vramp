define([
	"dojo/_base/connect",
	"dojo/_base/declare", 
	"dojo/ready",
	"dijit/_WidgetBase",
	"dijit/_TemplatedMixin",
	"dojo/dom-style",
	"dojo/dom-attr",
	"dojo/dom-class",
	"dojo/_base/array",
	"dojo/on",
	"dojo/_base/lang"
], function(connect, declare, ready, widgetBase, templatedMixin, domStyle, domAttr, domClass, array, on, lang) {
	
	return declare("amd/control/VideoManagerHtml5", [widgetBase, templatedMixin], {
		
		templateString: "<div class='media_video'>"+
			"<video id='video_node' data-dojo-attach-point='videoPlayer' class='${cssClass}'></video>"+
		"</div>" 			
			
		, laneID : ''
					    	
		, rootElement : 'div'
						    	
		, cssClass : 'video_class'
						    	
		, videoObjectId : ''
						    	
		, videoControls : null
						    	
		, videoAutoplay : null
						    	
		, videoPreload : 'auto'
						    	
		, videoLoop : null
						    	
		, videoPoster : 'images/rba/vramp-bg.png'
						    
		, videoMuted : null
						    	
		, videoWidth : '100%'
						    
		, videoHeight : '100%'
						    	
		, videoVolume : 0.9
		
		, loadingTime : 0
		
		, videos : []
	
		, disabledVideos: []
	
		, currentVideoIndex: -1

		, isThumbnail : false
	
		, hideOnDispose: true
		
		, cacheBustStr: ''
			
		, isPaused: false
			
		, doNotCacheDownloadedImage : false 
		
		// not used
		, sourceMediaTypes : { "mp4":"video/mp4", "m4a":"video/mp4", "m4b":"video/mp4", "m4r":"video/mp4", "m4v":"video/mp4", "m4p":"video/mp4", "flv":"video/mp4", "f4v":"video/mp4", "f4p":"video/mp4", "f4a":"video/mp4", "f4b":"video/mp4",
						    					   "ogg":"video/ogg", "ogv":"video/ogg", "oga":"video/ogg", "ogx":"video/ogg", "spx":"video/ogg", "opus":"video/ogg",
						    					   "webm":"video/webm", "mov":"video/mp4",
						    					   "mpg":"video/mpeg", "mpeg":"video/mpeg", "mp1":"video/mpeg", "mp2":"video/mpeg", "mp3":"video/mpeg", "m1v":"video/mpeg", "m1a":"video/mpeg", "m2a":"video/mpeg", "mpa":"video/mpeg", "mpv":"video/mpeg"
						    					 }
	
		, mySubscriptions : []
	
		, postMixInProperties: function() {
			
				this.inherited(arguments);
				var aSub = null;
				this.mySubscriptions = [];
	    	  	aSub = connect.subscribe("Any/VideoManager/CreateNew/" + this.laneID, this, this.createNewVideo);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("Any/VideoManager/PlayVideo/" + this.laneID, this, this.playVideo);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("Any/VideoManager/PauseVideo/" + this.laneID, this, this.pauseVideo);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("Any/VideoManager/DisposeVideo/" + this.laneID, this, this.disposeVideo);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("MultiMedia/Any/NewVideoData/" + this.laneID, this, this.setupCache);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("DisplayManger/Any/SetDoNotCacheDownloadedImage/" + this.laneID, this, this.setDoNotCacheDownloadedImageFlag);
                this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("Any/VideoManager/SetLoadingTime/" + this.laneID, this, this.setLoadingTime);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("MessageProcessor/Any/PhotoEnableDisable/" + this.laneID, this, this.enableDisableSlide);
				this.mySubscriptions.push(aSub);
				aSub = connect.subscribe("Any/PhotoEnableDisable/Reset/" + this.laneID, this, this.resetEnableDisableSlides);
				this.mySubscriptions.push(aSub);
				
	    	  	
		}
	
		, postCreate : function() {
		
			this.inherited(arguments);
			
			if(this.isThumbnail) {
				
				this.createNewVideo(this.videos, {"controls":"false"});
				this.videoPlayer.controls = false;
			}
			
			this.videoPlayer.addEventListener('ended', lang.hitch(this, 'videoEndedEvent'));
		}

		, destroy : function() {
			
			this.videoPlayer.removeEventListener('ended', lang.hitch(this, 'videoEndedEvent'));
			
			 for(aSub in this.mySubscriptions) {
				 
		  		  connect.unsubscribe(this.mySubscriptions[aSub]);
		  	  }
			 
			 this.inherited(arguments);
		}
		
		, setLoadingTime: function(loadingTime) {
			
			this.loadingTime = loadingTime;
		}
		
		, createNewVideo : function(source, preferredStartSrc, overridePlayerOptions) { 
			
			var hasMultipleSource = source instanceof Array;
			
			if(hasMultipleSource) {
				
				this.videos = source;
				
				var firstVideoIndex = this.getNextVideoIndex(0);
				
				if(firstVideoIndex == this.videos.length) {
					
					this.pauseVideo();
					this.lastVideoEnded();
					
					return;
				}
				
				var firstVideoSrc = this.videos[firstVideoIndex];
				
				if(preferredStartSrc !== undefined) {
					
					preferredStartSrc = preferredStartSrc.split(/[?#]/)[0];
					
					firstVideoIndex = this.getVideoIndex(preferredStartSrc);
					
					if(firstVideoIndex > -1) {
						
						firstVideoSrc = preferredStartSrc;
						
					} else {
						
						firstVideoIndex = 0;
					}
				}
				
				this.videoPlayer.setAttribute('type', "video/mp4");
				this.videoPlayer.setAttribute('src', firstVideoSrc + this.cacheBustStr);
				this.getPlayerOptions(overridePlayerOptions);
				this.videoPlayer.load();
				this.videoPlayed(firstVideoSrc + this.cacheBustStr, firstVideoIndex);
				this.currentVideoIndex = firstVideoIndex;
				
				if(this.hideOnDispose) {
					
					domClass.remove(this.domNode, "hide");
				}
				
			} else {
				
				this.videoPlayer.setAttribute('type', "video/mp4");
			    this.videoPlayer.setAttribute('src', source + this.cacheBustStr);
			    this.getPlayerOptions(overridePlayerOptions);
				this.videoPlayer.load();
				this.videoPlayed(source + this.cacheBustStr, 0);
				
				if(this.hideOnDispose) {
					
					domClass.remove(this.domNode, "hide");
				}
			}
		}
		
		, getVideoIndex: function(videoToCompare) {
			
			var tmpVideoUrl;
			
			for(i=0; i<this.videos.length; i++) {
				
				tmpVideoUrl = this.videos[i].split(/[?#]/)[0];
				
				if(tmpVideoUrl == videoToCompare) {
					
					return i;
				}
			}
			
			return -1;
		}

		, videoEndedEvent: function(e) {
			
			var ctx = this;
			var playingIndex = this.getNextVideoIndex(this.currentVideoIndex + 1);
			
			setTimeout(function() {
				
				if(playingIndex == ctx.videos.length) {

					ctx.pauseVideo();
					ctx.lastVideoEnded();
					
				} else {

					ctx.videoPlayer.setAttribute('src', ctx.videos[playingIndex] + ctx.cacheBustStr);
					ctx.isPaused = false;
					ctx.videoPlayer.load();
					ctx.videoPlayer.play();
					ctx.videoPlayed(ctx.videos[playingIndex] + ctx.cacheBustStr, playingIndex);
					ctx.currentVideoIndex = playingIndex;
				}
			}, ctx.loadingTime);
		}
		
		, getNextVideoIndex: function(currentVideoIndex) {
			
			var tmpVideoUrl;
			
			for(i=currentVideoIndex; i<this.videos.length; i++) {
				
				tmpVideoUrl = this.videos[i].split(/[?#]/)[0];
				
				if(this.disabledVideos.indexOf(tmpVideoUrl) == -1) {
					
					return i;
				}
			}
			
			return this.videos.length;
		}
		
		, areAllSlidesDisabled: function() {
			
			var firstEnableVideoIndex = this.getNextVideoIndex(0);
			
			if(firstEnableVideoIndex == this.videos.length) {
				
				return true;
			}
			
			return false;
		}
		
		, videoPlayed : function(videoUrl, index) {

			connect.publish('VideoManager/Any/VideoPlayed/' + this.laneID, [ videoUrl, index ]);
		}
		
		, lastVideoEnded : function() {

			connect.publish('VideoManager/Any/LastVideoEnded/' + this.laneID, [ this.areAllSlidesDisabled() ]);
		}
	   
	   , playVideo : function() {		   
			
		   if(this.videoPlayer) {
			   
			   this.isPaused = false;
			   this.videoPlayer.play();
		   }
	   }
	   
	   , pauseVideo : function() {	
		   
		   if(this.videoPlayer) {
			   
			   this.isPaused = true;
			   this.videoPlayer.pause();
		   }
	   }
	   
	   , disposeVideo : function() {  
		   
		  	this.pauseVideo();
		  	this.videos = [];
			domAttr.remove(this.videoPlayer, "src");
			domAttr.remove(this.videoPlayer, "type");
			this.videoPlayer.load();
			
			if(this.hideOnDispose) {

				domClass.add(this.domNode, "hide");

			}
	   }
	   
	   , enableDisableSlide: function(operation, videoEnableDisable) {
			
		   if(videoEnableDisable === "allimages") {
			   
			   return;
		   }
		   
		   if(videoEnableDisable === "all") {
				
				this.enableDisableAll(operation);
				
		   } else {
			   
			   videoEnableDisable = videoEnableDisable.split(/[?#]/)[0];
				
				if(operation == "enable") {
					
					var index = this.disabledVideos.indexOf(videoEnableDisable);
					
					if(index > -1) {
						
						this.disabledVideos.splice(index, 1);
					}
						
				} else if(operation == "disable") {
					
					this.disabledVideos.push(videoEnableDisable);
					
					if( ! this.isPaused) {
						
						var dataSource = domAttr.get(this.videoPlayer, "src");
						
						if(dataSource && dataSource.length > 0 && (videoEnableDisable == (dataSource.split(/[?#]/)[0]))) {
							
							this.pauseVideo();
							this.videoEndedEvent();
						}
					}
				}
		   }
	   }
	   
	   , resetEnableDisableSlides: function(itemDisabledMedia) {
		   
		   this.disabledVideos = [];
		   
		   if(itemDisabledMedia !== undefined) {
				
				this.copyUrls(itemDisabledMedia, this.disabledVideos);
			}
	   }
	   
	   , setupCache: function() {
		   
		   if(this.doNotCacheDownloadedImage) {
			   
			   this.cacheBustStr = "?ts=" + new Date().getTime();
			   
		   }  else {
				
				this.cacheBustStr = "";
		   }
	   }
	   
	   , setDoNotCacheDownloadedImageFlag : function(doNotCacheDownloadedImage) {
			
			this.doNotCacheDownloadedImage = doNotCacheDownloadedImage;
			this.setupCache();
		}
	     
	   , getPlayerOptions : function(overridePlayerOptions) {
		   
		   this.setPlayerOption("controls", this.videoControls, overridePlayerOptions["controls"]);		   
		   this.setPlayerOption("autoplay", this.videoAutoplay, overridePlayerOptions["autoplay"]);
		   this.setPlayerOption("preload", this.videoPreload, overridePlayerOptions["preload"]);
		   this.setPlayerOption("loop", this.videoLoop, overridePlayerOptions["loop"]);
		   /*this.setPlayerOption("poster", this.videoPoster, overridePlayerOptions["poster"]);*/
		   this.setPlayerOption("width", this.videoWidth, overridePlayerOptions["width"]);
		   this.setPlayerOption("height", this.videoHeight, overridePlayerOptions["height"]);
		   this.videoPlayer.volume = this.videoVolume; // Volume cannot be controlled through javascript in ios
	   }
	   
	   , setPlayerOption : function(key, defaultValue, overrideValue) {	
		   
		   if(overrideValue || defaultValue) {
			   
			   this.videoPlayer.setAttribute(key,overrideValue || defaultValue);
		   }
	   }
	   
	   , getSourceMediaType : function(source) {	
		   
		   var extension = this.getFileExtension(source);

		   return this.sourceMediaTypes[extension];
	   }
	    
	   , getFileExtension : function(filename) {
		   
		   return filename.split('.').pop().toString().toLowerCase();
	   }
	   
	   , enableDisableAll : function(operation) {
			
		   if(operation === "enable") {
			   
			   this.disabledVideos.length = 0;
			   
		   } else if(operation === "disable") {
			   
			   this.copyUrls(this.videos, this.disabledVideos);
			   
			   var dataSource = domAttr.get(this.videoPlayer, "src");
				
				if(dataSource && dataSource.length > 0) {
					
					this.pauseVideo();
					this.videoEndedEvent();
				}
		   }
	   }
	   
	   , copyUrls: function(source, dest) {
			
			var tmpMediaUrl;
			
			for(i=0; i<source.length; i++) {
				
				dest[i] = source[i].split(/[?#]/)[0];
			}
		}
		
	});
});
