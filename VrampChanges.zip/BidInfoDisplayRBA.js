var vrampWallBidInfo = "<div class='${cssAsk}'>" +
				   	   "	<label class='font--250 upperCase' data-dojo-attach-point='apAskSoldLabel'></label>" +
				   	   "	<div class='ask--price h-ta-right ccy CAD'>" +
				   	   "		<span class='auction-ccy'></span>" +
				   	   "		<div class='dollars font--400' data-dojo-attach-point='apAskSoldValue'></div>" +
				   	   "	</div>" +
				   	   "</div>"; 

var vrampWallMultiCurrencyAsk = "<div class='${cssAsk}'>" +
							 	"	<span class='dollars font--250' data-dojo-attach-point='apAskSoldValue'></span>" +
							 	"</div>";
							
var laneBidInfo = "<div>" +
				  "		<div class='${cssAsk}'>" +
				  "			<span class='${cssAskSoldLabel}' data-dojo-attach-point='apAskSoldLabel'></span>" +			            	
				  "			<span class='${cssAskSoldValue}' data-dojo-attach-point='apAskSoldValue'></span>" + 
				  "		</div>" +
				  "		<div class='${cssHighBid}' data-dojo-attach-point='apHighBidArea'>" +
				  "			<span class='${cssHighBidLabel}' data-dojo-type='amd/display/LanguageLabel' mytype='${highBidLabel}' laneID='${laneID}'></span>" +
				  "			<span class='${cssHighBidValue}' msgtype='currentBid' data-dojo-type='amd/display/MessageLabel'  hideParentforEmptyText ='true'  mytype='${mytype}' laneID='${laneID}' requiresReCalculation='${requiresReCalculation}'></span>" +	
				  "		</div>" +
				  "</div>"; 

var templateStringWithTextBox = "<div>" +
								"	<div class='${cssHighBid}'>" +
								"		<span class='asklabel' data-dojo-attach-point='apAskSoldLabel'></span>" +	
								"       <span data-dojo-attach-point='apAskSoldValue' class='asktxtctrlSpan' data-dojo-attach-event='onclick:showAskTextBox'></span>" +
								"		<input type='text' id='askTextBox' data-dojo-attach-event='keyPress:pushAskValue,onblur:showAskSpan'   data-dojo-attach-point='apAskSoldTextBoxValue' class='asktxtctrl' readonly='readonly'/>" + 
						    	"	</div>" +
						    	"	<div class='${cssHighBid}' data-dojo-attach-point='apHighBidArea'>" +
						    	"		<span class='bidlabel' data-dojo-type='amd/display/LanguageLabel' mytype='${newBidLabel}' laneID='${laneID}'></span>" +
						    	"		<div myTemplateType='templateWithInputBox' bidBoxClass='bidtxtctrl' data-dojo-attach-point='apBidSoldLabel' msgtype='currentBid' data-dojo-type='amd/display/MessageLabel' laneID='${laneID}' requiresReCalculation='${requiresReCalculation}'></div>" +	
					    		"		<div class='highbidder'>High Bidder:<br />" +
					    		"			<div msgtype='highBidder' data-dojo-type='amd/display/MessageLabel' hideParentforEmptyText ='true'  needLocalization='true' laneID='${laneID}'  ></div>" +
					    		"		</div>"+
						    	"	</div>" +
						    	"</div>";  

define([
	"dojo/_base/connect",
	"dojo/_base/declare", 
	"dojo/ready",
	"dijit/_WidgetBase",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dojo/dom-style",
	"amd/display/MessageLabel",
	"amd/display/LanguageLabel",
	"dojo/dom",
	"dojo/dom-attr",
	"dojo/query",
	"dojo/number",
	"dojo/dom-class"
	
], function(connect, declare, ready, widgetBase, templatedMixin, widgetsInTemplateMixin, domStyle, messageLabel, languageLabel, dom, domAttr, query, number, domClass) {
	
	return declare("amd/display/BidInfoDisplayRBA", [widgetBase, templatedMixin, widgetsInTemplateMixin], {
		
		templateString: laneBidInfo 

		, laneID : ''
		
		, askLabel : "ask"	  
		
		, lane2Verfied : false	
		          
		, i18nAskLabel : ''
					  
		, soldLabel : "sold"
					  
		, i18nSoldLabel : ''
					  
		, highBidLabel : 'highBid'
			
		, newBidLabel: 'highBidLblVRamp'	
					  
		, setAskPrice : false
				  
		, cssAsk : ''
					
		, cssHighBid : ''
			
		, currencySymbol : '' 
		
		, cssAskSoldLabel : "label" 
					  
		, cssAskSoldValue : "value"
					  
		, cssHighBidLabel : "label"
					  
		, cssHighBidValue : "value"
				  
		, requiresReCalculation : false
		
		, resetOnStartup : false
					 
		, currencyConverterWidget : ''
			
		, doNotDisplayDropDownOnChange : true
		
		, mySubscriptions : []
	
		, selectedDisplayCurrencyType : "symbol"
		
		, setSelectedDisplayCurrencyType : false
		
		, sendOnlyAmount : false
		
		, auctionCurrencyCode : ''
	
		, mytype : ""
			
		, myAltCurrencyType : ""
			
		, rawAskAmount : 0	
		
		, cntrlKeyPressed : false
		
		, isManual : false	
		
		, isLocked : true
		
		, currentItemRunname : ''
			
		, showSoldLabel : true
		
		, firstItemNav : false
		
		, askOnly : false
			
		, postMixInProperties: function() {
			
			this.inherited(arguments);
			
			var aSub = null;
			this.mySubscriptions = [];
			
			if(this.mytype == "templateStringWithTextBox") {
				
				this.templateString = templateStringWithTextBox;
			
			} else if(this.mytype == "vrampWallBidInfo") {
				
				this.templateString = vrampWallBidInfo;
				
			} else if(this.mytype == "vrampWallMultiCurrencyAsk") {

				this.templateString = vrampWallMultiCurrencyAsk;
			}
			
			aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetLanguageLabel" + this.laneID, this, this.setLanguageLabel);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetLabel" + this.laneID, this, this.setMyLabel);
      	    this.mySubscriptions.push(aSub);
            /* aSub = connect.subscribe("amd/display/BidInfoDisplayRBA/" + this.laneID, this, this.setAskBidValue);
      	  	this.mySubscriptions.push(aSub); */
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetAskLabel" + this.laneID, this, this.setNewAsklabel);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetAskPrice" + this.laneID, this, this.setMyAskPrice);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetSoldLabel" + this.laneID, this, this.setMySoldLabel);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetSoldPrice" + this.laneID, this, this.setMySoldPrice);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/Reset" + this.laneID, this, this.resetMe);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("AttendManager/CurrencyCode/SetSelectedDisplayCurrencyType/" + this.laneID, this, this.setDisplayCurrencyType);
      	  	this.mySubscriptions.push(aSub);
      	    aSub = connect.subscribe("AttendManager/CurrencyCode/SetAuctionCurrency/" + this.laneID, this, this.setAuctionCurrency);
    	  	this.mySubscriptions.push(aSub);
    	  	aSub = connect.subscribe("MessageProcessor/CandPOuterBlock/NewGroup/" + this.laneID, this, this.newGroup);
            this.mySubscriptions.push(aSub);
        	aSub = connect.subscribe("AttendManager/DataLabel/SetCurrencySymbol/" + this.laneID, this, this.addCurrencySymbol);
    	  	this.mySubscriptions.push(aSub);
    	  	aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/SetBidderCaptureOnDisplay" + this.laneID, this, this.setBidderCaptureOnDisplay);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("Any/BidInfoDisplayRBA/HideMe" + this.laneID, this, this.hideMe);
      	  	this.mySubscriptions.push(aSub);
      	  	aSub = connect.subscribe("CurrencyConverterRBA/BidInfoDisplayRBA/SetFlag" + this.laneID, this, this.setFlag);
      	  	this.mySubscriptions.push(aSub);
    	  	
    	  	if(this.mytype == "templateStringWithTextBox") {
    	  		
	    	  	aSub = connect.subscribe("ManualClerkOnOff/Any/SetManualClerkState/" + this.laneID, this, this.toggleManualClerkState);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("LockUnlock/Any/SetLockState/" + this.laneID, this, this.toggleLockState);
	      	  	this.mySubscriptions.push(aSub);
	      	    aSub = connect.subscribe("DataManager/Anyone/ItemNav/" + this.laneID, this, this.setCurrentRunname);
	    	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("BidButton/BidInfoDisplayRBA/AskValue/" + this.laneID, this, this.setRawAsk);
	     	  	this.mySubscriptions.push(aSub);
	    	  	aSub = connect.subscribe("Clerk/Message/CtrlKeyPressed/", this, this.ctrlKeyPressed);
	    	  	this.mySubscriptions.push(aSub);
    	  	}	
	      	  	
      	/*  	aSub = connect.subscribe("CurrencyConverter/CurrencyWidgetHolder/HideMe" + this.laneID, this, this.hideCurrencyWidget);
      	  	this.mySubscriptions.push(aSub);*/
            
      	  	if(this.requiresReCalculation) {
      		  
      	  		aSub = connect.subscribe("MessageProcessor/AskSoldDisplay/ReSetValue" + this.laneID, this, this.setMyValue);
      	  		this.mySubscriptions.push(aSub);
      	  	}
		}
	
		, postCreate : function() {
			
			this.inherited(arguments);
		}

		, newGroup : function(data) {
			
			this.rawAskAmount = 0;
			
			this.firstItemNav = true;
		}
		
		
		, destroy : function() {
			
			this.inherited(arguments);
			
			 for(aSub in this.mySubscriptions) {
				 
		  		  connect.unsubscribe(this.mySubscriptions[aSub]);
		  	  }
		}
		
		, setDisplayCurrencyType : function(displayCurrencyType) {
			
			this.selectedDisplayCurrencyType = displayCurrencyType;
		}
		
		, setAuctionCurrency : function(auctionCurrency) {
			
			this.auctionCurrencyCode = auctionCurrency;
			
			if(this.mytype == "vrampWallBidInfo") {
				
				query(".auction-ccy").addClass(auctionCurrency);
			}
			
		}
		, setLanguageLabel : function() {
			
			this.i18nAskLabel = this.getLanguageLabel(this.askLabel);
  			this.i18nSoldLabel = this.getLanguageLabel(this.soldLabel);
  			
  			if (this.resetOnStartup) {
				
				this.setNewAsklabel();
				
			}
  			
		}
		
		, ctrlKeyPressed : function (evtCode) {
			
			if(evtCode=="17") {
				
				if(this.isManual && this.isLocked && this.firstItemNav) {
					
					 if( this.currentItemRunname !== 'undefined' && this.currentItemRunname !="" && this.rawAskAmount > 0) {
							
						connect.publish("Any/BidButton/SetFirstTimeNavFlag/" + this.laneID, []);
						connect.publish("sendAskIncrementValue/" , [this.laneID , "", this.rawAskAmount]);
						
						this.firstItemNav = false;
					}
				}
			}
		}
		
		, addCurrencySymbol : function(currencySymbol) {
			
			this.currencySymbol = currencySymbol;
		} 
		
		, setRawAsk : function(val, operator) {
			
			if(operator == "+") {
				
				this.rawAskAmount += parseInt(val);
				
			} else {
				
				if(this.rawAskAmount > parseInt(val)) {
					
					this.rawAskAmount -= parseInt(val);
				}
				
			}
			
			if(this.rawAskAmount > 0) {
				
				var displayAmount = this.addCommaFormatted(this.rawAskAmount);
				this.apAskSoldValue.innerHTML = this.currencySymbol+displayAmount ;
				this.apAskSoldTextBoxValue.value = this.currencySymbol+displayAmount;
			}
			
		}
		
		, setMyLabel : function(label, type) {
			
			if(this.mytype == "vrampWallBidInfo") {
				
				if(type == "sold") {
					
					query(".prices").addClass("s-sold");
					query(".altCurrApprxText").style("color","#ffffff");
					query(this.apAskSoldLabel).addClass("s-sold");
					this.apAskSoldLabel.innerHTML = "<i class='c-brand icon-sold'></i>" + label;
					
				} else {
					
					query(".prices").removeClass("s-sold"); 
					query(".altCurrApprxText").style("color","#7d3d0d");
					query(this.apAskSoldLabel).removeClass("s-sold");
					this.apAskSoldLabel.innerHTML = label;
					query(".auction-ccy").addClass(this.auctionCurrencyCode);
				}
				
			} else if(this.mytype != "vrampWallMultiCurrencyAsk") {
				
				this.apAskSoldLabel.innerHTML = label;
			}
		}
		
		, toggleManualClerkState : function(manualClerkState) {
			
			this.isManual = manualClerkState;
			
			this.setAskInputBoxState();

		}
		
		, toggleLockState : function(lockState) {
			
			this.isLocked = lockState;
			
			this.setAskInputBoxState();
		}
		
		, setCurrentRunname : function(dbRef) {
			
			var theItem = dbRef.getCurrentItem(this.laneID);

			if(typeof theItem !== 'undefined') {
				
				this.currentItemRunname = theItem.runname;
			}
			
			this.rawAskAmount = 0;
			
			connect.publish("BidInfoDisplayRBA/BidButton/getBidValue/" + this.laneID, [ ]);
		}
		
		, pushAskValue : function(evt) {

			if(evt.keyCode != 8) {
				
				  var theEvent = evt || window.event;
		
				  var keyCode = theEvent.keyCode || theEvent.which;
				  
				  var key = String.fromCharCode(keyCode);
				  
				  var regex = /[0-9]/;
					
				  if(!regex.test(key)) {
					  
					  if(keyCode == 37 || keyCode == 39 || keyCode == 13 || keyCode == 36 || keyCode == 35) {
						  
						  if (keyCode == 13) {
								
								var askAmount =  this.apAskSoldTextBoxValue.value;
								
								askAmount = this.removeCurrenySymbol(askAmount);
								
								askAmount = this.removeComma(askAmount);
								
								if( this.currentItemRunname !== 'undefined' && this.currentItemRunname !="" ) {
									
									connect.publish("sendAskIncrementValue/" , [this.laneID , "", askAmount]);
									
								} else {
									
									this.apAskSoldTextBoxValue.value = '';
									
									connect.publish("Any/ClerkInfoPopUp/sendErrorMessage/" +this.laneID,  ['lotNotOnBlock']);
								}
								
							}
						  
					  } else {
						  
						  theEvent.returnValue = false;
						    
						  if(theEvent.preventDefault) {
					    	
							  theEvent.preventDefault();
						  }
						  
						  return;
					  }
					  
				  }
				  
				  return key;
			  }
		 }
		
		, removeComma : function(val) {
			
			return val.replace(",","");
		}
		
		, removeCurrenySymbol : function(val) {
			
			val = val.replace(this.currencySymbol,"");
			
			return val;
		}
		
		, isInvalidKey : function(keycode) {
			
			if(keycode==37 || keycode == 39 && keycode == 8) {
				
				return false;
			}
			
			return true;
		}
		
		, showAskTextBox : function() {
			
			domStyle.set(this.apAskSoldValue, "display", "none");
			
			domStyle.set(this.apAskSoldTextBoxValue, "display", "block");
			
			this.apAskSoldTextBoxValue.focus();
			
		}
		
		, showAskSpan : function () {
			
			this.apAskSoldValue.innerHTML = this.apAskSoldTextBoxValue.value;
			
			domStyle.set(this.apAskSoldValue, "display", "block");
			
			domStyle.set(this.apAskSoldTextBoxValue, "display", "none");
		}
		
		, setAskInputBoxState : function() {
			
			if(this.isManual && this.isLocked) {
				
				domAttr.remove(this.apAskSoldTextBoxValue, 'readonly');
				
			} else {
				
				domAttr.set(this.apAskSoldTextBoxValue, "readonly", "readonly");
			}
			
		}
		
		, getInputSelection : function(el){
			
		    var start = 0, end = 0, normalizedValue, range,
		        textInputRange, len, endRange;

		    if (typeof el.selectionStart == "number" && typeof el.selectionEnd == "number") {
		        start = el.selectionStart;
		        end = el.selectionEnd;
		    } else {
		        range = document.selection.createRange();

		        if (range && range.parentElement() == el) {
		            len = el.value.length;
		            normalizedValue = el.value.replace(/\r\n/g, "\n");

		            // Create a working TextRange that lives only in the input
		            textInputRange = el.createTextRange();
		            textInputRange.moveToBookmark(range.getBookmark());

		            // Check if the start and end of the selection are at the very end
		            // of the input, since moveStart/moveEnd doesn't return what we want
		            // in those cases
		            endRange = el.createTextRange();
		            endRange.collapse(false);

		            if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
		                start = end = len;
		            } else {
		                start = -textInputRange.moveStart("character", -len);
		                start += normalizedValue.slice(0, start).split("\n").length - 1;

		                if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
		                    end = len;
		                } else {
		                    end = -textInputRange.moveEnd("character", -len);
		                    end += normalizedValue.slice(0, end).split("\n").length - 1;
		                }
		            }
		        }
		    }

		    return {
		        start: start,
		        end: end
		    };
		}

		, offsetToRangeCharacterMove : function (el, offset) {
			
		    return offset - (el.value.slice(0, offset).split("\r\n").length - 1);
		}

		, setInputSelection : function(el, startOffset, endOffset) {
			
		    if (typeof el.selectionStart == "number" && typeof el.selectionEnd == "number") {
		        el.selectionStart = startOffset;
		        el.selectionEnd = endOffset;
		    } else {
		        var range = el.createTextRange();
		        var startCharMove = offsetToRangeCharacterMove(el, startOffset);
		        range.collapse(true);
		        if (startOffset == endOffset) {
		            range.move("character", startCharMove);
		        } else {
		            range.moveEnd("character", offsetToRangeCharacterMove(el, endOffset));
		            range.moveStart("character", startCharMove);
		        }
		        range.select();
		    }
		}
		
		, setAskBidValue :function (ask,bid) {
			
			if(this.mytype == "templateStringWithTextBox") {
				
				this.apBidSoldLabel.innerHTML = bid;
				
				this.apAskSoldValue.innerHTML = ask;
				
				this.apAskSoldTextBoxValue.value = ask;
				
			} else {
				
				this.apAskSoldValue.innerHTML = ask;
			}
			
		}
		, setMyValue : function(value, myAltCurrencyType) {
			
			if(this.mytype == "templateStringWithTextBox") {
				
				this.apAskSoldValue.innerHTML = value;
				
				this.apAskSoldTextBoxValue.value = value;
				
			} else if(this.mytype == "vrampWallMultiCurrencyAsk") {
				if(this.myAltCurrencyType == "" || this.myAltCurrencyType == myAltCurrencyType) {
					if (value != ""){											
                        if(!dom.byId('amd/display/BidInfoDisplayRBA_1').className.match("null hide")){
                            domStyle.set(dom.byId("altCurrLabel1"), "display", "block");
                        }
					}else{
                        domStyle.set(dom.byId("altCurrLabel1"), "display", "none");
					}
                    this.apAskSoldValue.innerHTML = value;
                }

            } else {

                if((this.mytype == "multilane" ||  this.mytype == "multicurrency") && value.length > 10 ){

                    this.apAskSoldValue.innerHTML = value;
					
				 } else {
					 
					 if(this.lane2Verfied){
						 
						 this.apAskSoldValue.innerHTML = value.replace(this.currencySymbol," ");
						 
					 } else {
						 
						 this.apAskSoldValue.innerHTML = value;
					 }
					
					 
				 }
			}
		}

		, setNewAsklabel : function() {
			
  			this.resetMe(this.i18nAskLabel);
		}

		, setMyAskPrice : function(askPrice) {
			
			if (!this.isLocked && askPrice != "" && this.apAskSoldLabel.innerHTML == this.i18nSoldLabel) {
				
				this.resetMe(this.i18nAskLabel);
			}
			
			if(this.setAskPrice) {
  				
  				if(this.requiresReCalculation) {
  					
  					connect.publish("AttendManager/CurrencyCode/GotNewAsk/" + this.laneID, [ askPrice ]);
  					
  				} else {
  					
  					if (askPrice != "") {
  						
  						this.setMyValue(this.addDisplayCurrencyType(askPrice, this.auctionCurrencyCode));
  					
  					} else {
  						
  						this.setMyValue("");
  					}
  				}
  			}

		}
		
		, addDisplayCurrencyType : function (fmtCurrency, currencyCode) {
			
			if(this.sendOnlyAmount) {
				 
				 return fmtCurrency.replace(/[^0-9\.,]+/g,"");
			 }
			
			 if(this.setSelectedDisplayCurrencyType) {
				 
				 if(this.selectedDisplayCurrencyType == "symbol") {
					 
					 return fmtCurrency;
					 
				 } else {
					 
					 var theCurrentAsk = fmtCurrency.replace(/[^0-9\.,]+/g,"");
					 
					 return currencyCode + "&nbsp;"+ theCurrentAsk;
				 }
				 
			 } else {
				 
				 return fmtCurrency;
			 }
			 
		 }

		, addCommaFormatted : function(amount) {
			
			var frmtd = number.format(amount);
		       
			return frmtd;
		}
		
		, setMySoldLabel : function() {
			
		   this.setAskPrice = false;
		   
		   if(this.showSoldLabel) {
		   
		      this.setMyLabel(this.i18nSoldLabel, "sold");
		      
		      if(this.mytype == "templateStringWithTextBox") {
		       
		        query(".bidlabel").style("visibility", "hidden");
		        
		        connect.publish("Clerk/MessageLabel/ResetBidBoxValue/" + this.laneID, [ '' ]);
		        
		      } else if(!this.askOnly) {
		       
		       this.hideHighBidArea();
		      }
		      
		   } else {
		    
		    this.setMyLabel("&nbsp;");
		   }
		   
		}

		, setBidderCaptureOnDisplay : function(currentHighBidPrice) {
			
			this.setMySoldLabel();
			this.setMySoldPrice(currentHighBidPrice);
		}
		
		, setMySoldPrice : function(soldPrice) {
			
  			if (soldPrice != "") {
  				
  				if(this.requiresReCalculation) {
  					
  					connect.publish("AttendManager/CurrencyCode/GotNewAsk/" + this.laneID, [ soldPrice ]);
  					
  				} else {
  					
  					this.setMyValue(this.addDisplayCurrencyType(soldPrice, this.auctionCurrencyCode));
  				}

  			}
		}

		, resetMe : function(label) {
			
  			this.setAskPrice = true;
  			
  			if(this.mytype != "vrampWallMultiCurrencyAsk") {

  				this.setMyLabel(label);
  			}
  			
  			if(this.requiresReCalculation) {
  				
  				connect.publish("AttendManager/CurrencyCode/GotNewAsk/" + this.laneID, [ '' ]);
					
  			} else {
					
  				this.setMyValue("");
  			}
  			
  			if(!this.askOnly) {
  			
  				this.showHighBidArea();
  			}
  			
  			connect.publish('MessageProcessor/AskLabel/SetBuyerPlace' + this.laneID, [ '' ]);
		}

		, getLanguageLabel : function(code) { 
			
      	  	var labelValue = attendManager.getLaneLanguageLabel(this.laneID, code.toLowerCase());
      	  	if (!labelValue) {
      	  	
      	  		labelValue = code;
  		  	}
      	  	return labelValue;
		}

		, hideHighBidArea : function() {
  		
			domStyle.set(this.apHighBidArea, "visibility", "hidden");
		}

		, showHighBidArea : function() {
			
  			domStyle.set(this.apHighBidArea, "visibility", "visible");
  			
  			if(this.mytype == "templateStringWithTextBox") {
  				
 				 query(".bidlabel").style("visibility", "visible");
  			}
		}
		
		, hideMe : function(myAltCurrencyType) {
			
			if(this.myAltCurrencyType == myAltCurrencyType) {
				
				domClass.add(this.domNode, "hide");
			}
		}
		
		, setFlag : function(currencyCode, myAltCurrencyType) {
			
			if(this.myAltCurrencyType == myAltCurrencyType) {
				
				domClass.add(this.domNode, currencyCode);
			}
		}
		
	});
});
